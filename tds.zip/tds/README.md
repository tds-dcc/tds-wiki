# Curso #

Taller de Software 2022

Diplomado en Ingeniería de Software

Departamento de Ciencias de la Computación

Universidad de Chile



## Profesor ##

Daniel Perovich (dperovic@dcc.uchile.cl)
